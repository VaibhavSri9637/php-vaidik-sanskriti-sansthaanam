<div class="footer">
    <div class="footer-content">
        <a href="/" class="unstyled-link lato-regular" alt="Vedic Sanskriti Sansthaanam">
            © 2022 Vedic Sanskriti Sansthanam
        </a>
    </div>
</div>