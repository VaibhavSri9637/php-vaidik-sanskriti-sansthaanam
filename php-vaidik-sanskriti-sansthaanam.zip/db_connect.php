<?php
$conn = mysqli_connect('localhost', 'root', 'nf16Mysql', 'vaidic_sanskriti_sansthaanam');
if (!$conn) {
    echo 'Connection error: ' . mysqli_connect_error();
}
